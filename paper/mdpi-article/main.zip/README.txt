HARK manuscript — LaTeX source package for submission to Computers (MDPI)
=========================================================================

Contents
  main.tex        manuscript source (single file; bibliography inline)
  main.pdf        compiled manuscript (A4)
  Definitions/    MDPI class, bibliography styles and logos

Build
  Two pdflatex passes, with Definitions/ kept beside main.tex:

      pdflatex -interaction=nonstopmode main.tex
      pdflatex -interaction=nonstopmode main.tex

  No BibTeX/Biber run is required: all 41 references are inline \bibitem entries.
  Compiled with pdfTeX 1.40.25 (TeX Live 2023).

Notes
  The running header prints \today, so a later recompile changes only that line.
  The bundled MDPI class differs from the upstream copy only in two logo
  references (EPS replaced by the shipped PDF); no shell escape is needed.
